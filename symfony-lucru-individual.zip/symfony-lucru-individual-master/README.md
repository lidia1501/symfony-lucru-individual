Symfony lucru individual

Step 1. Download the repository

Step 2. Run composer install

Step 3. Run `symfony server:start`